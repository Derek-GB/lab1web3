<?php // Preloader HTML Codes

if ( bard_options( 'preloader_label' ) === true ) : ?>

<div class="bard-preloader-wrap">

	<div class="cssload-container">
		<div id="loadFacebookG">
			<div id="blockG_1" class="facebook_blockG"></div>
			<div id="blockG_2" class="facebook_blockG"></div>
			<div id="blockG_3" class="facebook_blockG"></div>
		</div>
	</div>

</div><!-- .bard-preloader-wrap -->

<?php endif; ?>